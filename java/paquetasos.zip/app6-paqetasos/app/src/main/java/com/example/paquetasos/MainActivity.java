package com.example.paquetasos;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private CheckBox chetoBolita = null;
    private CheckBox frito = null;
    private CheckBox crujitoFlamin = null;
    private CheckBox churrumais = null;
    private CheckBox dorito3d = null;
    private CheckBox crujito = null;
    private CheckBox doritoFlamin = null;
    private CheckBox sabritoneRodacaFlamin = null;
    private CheckBox sabritone = null;
    private CheckBox chetoPoff = null;
    private CheckBox chetoFlamin = null;
    private CheckBox rancherito = null;
    private CheckBox sabritoneRodaca = null;
    private CheckBox chetoPalomita = null;
    private CheckBox tostitoFlamin = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button btnEnviar = findViewById(R.id.btnEnviar);
        chetoBolita = findViewById(R.id.chetoBolita);
        frito = findViewById(R.id.frito);
        crujitoFlamin = findViewById(R.id.crujitoFlamin);
        churrumais = findViewById(R.id.churrumais);
        dorito3d = findViewById(R.id.dorito3d);
        crujito = findViewById(R.id.crujito);
        doritoFlamin = findViewById(R.id.doritoFlamin);
        sabritoneRodacaFlamin = findViewById(R.id.sabritoneRodacaFlamin);
        sabritone = findViewById(R.id.sabritones);
        chetoPoff = findViewById(R.id.chetoPoff);
        chetoFlamin = findViewById(R.id.chetoFlamin);
        rancherito = findViewById(R.id.rancherito);
        sabritoneRodaca = findViewById(R.id.sabritoneRodaca);
        chetoPalomita = findViewById(R.id.chetoPalomita);
        tostitoFlamin = findViewById(R.id.tostitoFlamin);

        btnEnviar.setOnClickListener(v ->{
            Intent intent = new Intent(this, MainActivity2.class);

            ArrayList<Object> seleccionados = new ArrayList<>();

            if (chetoBolita.isChecked()) seleccionados.add("chetoBolita");
            if (frito.isChecked()) seleccionados.add("frito");
            if (crujitoFlamin.isChecked()) seleccionados.add("crujitoFlamin");
            if (churrumais.isChecked()) seleccionados.add("churrumais");
            if (dorito3d.isChecked()) seleccionados.add("dorito3d");
            if (crujito.isChecked()) seleccionados.add("crujito");
            if (doritoFlamin.isChecked()) seleccionados.add("doritoFlamin");
            if (sabritoneRodacaFlamin.isChecked()) seleccionados.add("sabritoneRodacaFlamin");
            if (sabritone.isChecked()) seleccionados.add("sabritone");
            if (chetoPoff.isChecked()) seleccionados.add("chetoPoff");
            if (chetoFlamin.isChecked()) seleccionados.add("chetoFlamin");
            if (rancherito.isChecked()) seleccionados.add("rancherito");
            if (sabritoneRodaca.isChecked()) seleccionados.add("sabritoneRodaca");
            if (chetoPalomita.isChecked()) seleccionados.add("chetoPalomita");
            if (tostitoFlamin.isChecked()) seleccionados.add("tostitoFlamin");

            intent.putExtra("seleccionados", seleccionados);
            startActivity(intent);
        });

    }


}