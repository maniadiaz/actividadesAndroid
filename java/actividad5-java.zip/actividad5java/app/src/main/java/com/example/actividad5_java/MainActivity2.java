package com.example.actividad5_java;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity2 extends AppCompatActivity {

    private TextView txtResultado;
    private Button btnRegresar;
    private Intent intent;
    private String ingrediente1;
    private String ingrediente2;
    private String ingrediente3;
    private String ingrediente4;
    private String resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        txtResultado = findViewById(R.id.txtResultado);
        btnRegresar = findViewById(R.id.btnRegresar);
        intent = getIntent();

        ingrediente1 = intent.getStringExtra("ingrediente1");
        ingrediente2 = intent.getStringExtra("ingrediente2");
        ingrediente3 = intent.getStringExtra("ingrediente3");
        ingrediente4 = intent.getStringExtra("ingrediente4");

        /*
            Expresso :
            1.- cafe
        */

        if(ingrediente1.equals("Cafe") && ingrediente2.equals("Nada") && ingrediente3.equals("Nada") && ingrediente4.equals("Nada")){
            resultado = "Expresso";
        }else
        /*
        Americano :
        1.- Cafe
        2.- Agua
        */
        if (ingrediente1.equals("Cafe") && ingrediente2.equals("Agua caliente") && ingrediente3.equals("Nada") && ingrediente4.equals("Nada")) {
            resultado = "Americano";
        }else
        /*
            Cappuccino :
            1.- cafe
            2.- Leche
            3.- Vainilla
            4.- Espuma de leche
         */
        if (ingrediente1.equals("Cafe") && ingrediente2.equals("Leche evaporada") && ingrediente3.equals("Vainilla") && ingrediente4.equals("Espuma de leche")) {
            resultado = "Cappuccino";
        }else
        /*
            Latte :
            1.- Cafe
            2.- Leche
            3.- Espuma de leche
         */
        if (ingrediente1.equals("Cafe") && ingrediente2.equals("Leche evaporada") && ingrediente3.equals("Espuma de leche") && ingrediente4.equals("Nada")) {
            resultado = "Latte";
        }else
        /*
            Machiatto :
            1.- Cafe
            2.- Leche
         */
        if (ingrediente1.equals("Cafe") && ingrediente2.equals("Leche evaporada") && ingrediente3.equals("Nada") && ingrediente4.equals("Nada")) {
            resultado = "Macchiato";
        }else
        /*
            Mocca :
            1.- Chocolate
            2.- Cafe
            3.- leche
            4.- Espuma de leche
         */
        if (ingrediente1.equals("Chocolate") && ingrediente2.equals("Cafe") && ingrediente3.equals("Leche evaporada") && ingrediente4.equals("Espuma de leche")) {
            resultado = "Mocca";
        }else
        /*
            Carajillo :
            1.- Cafe
            2.- Orujo/Brandy
         */
        if (ingrediente1.equals("Cafe") && ingrediente2.equals("Orijo/Brandy") && ingrediente3.equals("Nada") && ingrediente4.equals("Nada")) {
            resultado = "Carajillo";
        }else

        /*
            Irish :
            1.- Cafe
            2.- Whiskey
            3.- Espuma de leche
         */
        if (ingrediente1.equals("Cafe") && ingrediente2.equals("Whiskey") && ingrediente3.equals("Espuma de leche") && ingrediente4.equals("Nada")) {
            resultado = "Irish Coffee";
        }else{
            resultado = "No se encontró una coincidencia para este café.";
        }

        txtResultado.setText("Café : " + resultado);


        btnRegresar.setOnClickListener(v -> {
            setResult(RESULT_OK,intent);
            finish();
        });
    }
}