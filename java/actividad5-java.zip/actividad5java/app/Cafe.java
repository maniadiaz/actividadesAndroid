import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
public class Cafe {
    private static final Map<String, Set<String>> recetas = new HashMap<>();

    static {
        recetas.put("Capuchino", new HashSet<>(Set.of("Café", "Leche vaporizada", "Espuma de leche")));
        recetas.put("Macchiato", new HashSet<>(Set.of("Café", "Leche evaporada")));
        recetas.put("Mocca", new HashSet<>(Set.of("Chocolate", "Café", "Leche evaporada")));
        recetas.put("Americano", new HashSet<>(Set.of("Café", "Agua")));
        recetas.put("Azteca", new HashSet<>(Set.of("Café", "Leche evaporada", "Helado")));
    }

    public static String identificarCafe(Set<String> ingredientesUsuario) {
        for (Map.Entry<String, Set<String>> entry : recetas.entrySet()) {
            if (entry.getValue().equals(ingredientesUsuario)) {
                return "☕ Tu café es: " + entry.getKey();
            }
        }
        return "X No se encontró un café con esos ingredientes.";
    }

}
