package com.example.app10_java;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainApp05_PantallaPrincipal extends AppCompatActivity {

    private Spinner spinnerIngrediente1;
    private Spinner spinnerIngrediente2;
    private Spinner spinnerIngrediente3;
    private Spinner spinnerIngrediente4;
    private Intent intent;
    private Button btnEnviar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main_app05_pantalla_principal);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        spinnerIngrediente1 = findViewById(R.id.spinner1);
        spinnerIngrediente2 = findViewById(R.id.spinner2);
        spinnerIngrediente3 = findViewById(R.id.spinner3);
        spinnerIngrediente4 = findViewById(R.id.spinner4);
        btnEnviar = findViewById(R.id.btnGenerar);

        String[] ingrediente1 = {"Selecciona un ingrediente", "Cafe", "Chocolate"};
        String[] ingrediente2 = {"Selecciona un ingrediente", "Nada", "Agua caliente", "Leche evaporada", "Cafe", "Orijo/Brandy", "Whiskey"};
        String[] ingrediente3 = {"Selecciona un ingrediente", "Nada", "Vainilla", "Espuma de leche", "Leche evaporada"};
        String[] ingrediente4 = {"Selecciona un ingrediente", "Nada", "Espuma de leche"};

        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, ingrediente1);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerIngrediente1.setAdapter(adapter1);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, ingrediente2);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerIngrediente2.setAdapter(adapter2);
        ArrayAdapter<String> adapter3 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, ingrediente3);
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerIngrediente3.setAdapter(adapter3);
        ArrayAdapter<String> adapter4 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, ingrediente4);
        adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerIngrediente4.setAdapter(adapter4);

        btnEnviar.setOnClickListener(v -> {
            String ingre1 = spinnerIngrediente1.getSelectedItem().toString();
            String ingre2 = spinnerIngrediente2.getSelectedItem().toString();
            String ingre3 = spinnerIngrediente3.getSelectedItem().toString();
            String ingre4 = spinnerIngrediente4.getSelectedItem().toString();

            if(ingre1.equals("Selecciona un ingrediente") || ingre2.equals("Selecciona un ingrediente") || ingre3.equals("Selecciona un ingrediente") || ingre4.equals("Selecciona un ingrediente")){
                Toast.makeText(this, "Por favor, selecciona todo los ingrediente", Toast.LENGTH_SHORT).show();
            }else{
                intent = new Intent(this, MainApp05_PantallaResultado.class);
                intent.putExtra("ingrediente1",ingre1);
                intent.putExtra("ingrediente2",ingre2);
                intent.putExtra("ingrediente3",ingre3);
                intent.putExtra("ingrediente4",ingre4);

                startActivity(intent);
            }
        });

        Button btnRegresar = findViewById(R.id.btnRegresar);

        btnRegresar.setOnClickListener(v -> finish());
    }
}