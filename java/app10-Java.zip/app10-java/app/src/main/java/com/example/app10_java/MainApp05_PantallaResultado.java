package com.example.app10_java;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainApp05_PantallaResultado extends AppCompatActivity {

    private TextView txtResultado;
    private Button btnRegresar;
    private Intent intent;
    private String ingrediente1;
    private String ingrediente2;
    private String ingrediente3;
    private String ingrediente4;
    private String resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main_app05_pantalla_resultado);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        txtResultado = findViewById(R.id.txtResultado);
        btnRegresar = findViewById(R.id.btnRegresar);
        intent = getIntent();

        ingrediente1 = intent.getStringExtra("ingrediente1");
        ingrediente2 = intent.getStringExtra("ingrediente2");
        ingrediente3 = intent.getStringExtra("ingrediente3");
        ingrediente4 = intent.getStringExtra("ingrediente4");

        if(ingrediente1.equals("Cafe") && ingrediente2.equals("Nada") && ingrediente3.equals("Nada") && ingrediente4.equals("Nada")){
            resultado = "Expresso";
        }else if (ingrediente1.equals("Cafe") && ingrediente2.equals("Agua caliente") && ingrediente3.equals("Nada") && ingrediente4.equals("Nada")) {
            resultado = "Americano";
        }else if (ingrediente1.equals("Cafe") && ingrediente2.equals("Leche evaporada") && ingrediente3.equals("Vainilla") && ingrediente4.equals("Espuma de leche")) {
            resultado = "Cappuccino";
        }else if (ingrediente1.equals("Cafe") && ingrediente2.equals("Leche evaporada") && ingrediente3.equals("Espuma de leche") && ingrediente4.equals("Nada")) {
            resultado = "Latte";
        }else if (ingrediente1.equals("Cafe") && ingrediente2.equals("Leche evaporada") && ingrediente3.equals("Nada") && ingrediente4.equals("Nada")) {
            resultado = "Macchiato";
        }else if (ingrediente1.equals("Chocolate") && ingrediente2.equals("Cafe") && ingrediente3.equals("Leche evaporada") && ingrediente4.equals("Espuma de leche")) {
            resultado = "Mocca";
        }else if (ingrediente1.equals("Cafe") && ingrediente2.equals("Orijo/Brandy") && ingrediente3.equals("Nada") && ingrediente4.equals("Nada")) {
            resultado = "Carajillo";
        }else if (ingrediente1.equals("Cafe") && ingrediente2.equals("Whiskey") && ingrediente3.equals("Espuma de leche") && ingrediente4.equals("Nada")) {
            resultado = "Irish Coffee";
        }else{
            resultado = "No se encontró una coincidencia para este café.";
        }

        txtResultado.setText("Café : " + resultado);

        btnRegresar.setOnClickListener(v -> {
            setResult(RESULT_OK,intent);
            finish();
        });
    }
}