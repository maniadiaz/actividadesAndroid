package com.example.app10_java;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        // instanciar de botones
        Button btnApp01 = findViewById(R.id.btnApp01);
        Button btnApp02 = findViewById(R.id.btnApp02);
        Button btnApp03 = findViewById(R.id.btnApp03);
        Button btnApp04 = findViewById(R.id.btnApp04);
        Button btnApp05 = findViewById(R.id.btnApp05);
        Button btnApp06 = findViewById(R.id.btnApp06);
        Button btnApp07= findViewById(R.id.btnApp07);
        Button btnApp08 = findViewById(R.id.btnApp08);
        Button btnApp09 = findViewById(R.id.btnApp09);

        // instanciar los intent
        Intent intent01 = new Intent(this, MainApp01.class);
        Intent intent02 = new Intent(this, MainApp02.class);
        Intent intent03 = new Intent(this, MainApp03.class);
        Intent intent04 = new Intent(this, MainApp04_pantallaPrincipal.class);
        Intent intent05 = new Intent(this, MainApp05_PantallaPrincipal.class);
        Intent intent06 = new Intent(this, MainApp06_PantallaPrincipal.class);
        Intent intent07 = new Intent(this, MainApp07_PantallaPrincipal.class);
        Intent intent08 = new Intent(this, MainApp08_PantallaPrincipal.class);
        Intent intent09 = new Intent(this, MainApp09_PantallaPrincipal.class);

        // App 01
        btnApp01.setOnClickListener(v ->{
            startActivity(intent01);
        });

        // App 02
        btnApp02.setOnClickListener(v ->{
            startActivity(intent02);
        });

        // App 03
        btnApp03.setOnClickListener(v ->{
            startActivity(intent03);
        });

        // App 04
        btnApp04.setOnClickListener(v ->{
            startActivity(intent04);
        });

        // App 05
        btnApp05.setOnClickListener(v ->{
            startActivity(intent05);
        });

        // App 06
        btnApp06.setOnClickListener(v ->{
            startActivity(intent06);
        });

        // App 07
        btnApp07.setOnClickListener(v ->{
            startActivity(intent07);
        });

        // App 08
        btnApp08.setOnClickListener(v ->{
            startActivity(intent08);
        });

        // App 09
        btnApp09.setOnClickListener(v ->{
            startActivity(intent09);
        });




    }
}