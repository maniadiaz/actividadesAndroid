package com.example.app10_java;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.example.app10_java.databinding.ActivityMainApp07PantallaPrincipalBinding;

public class MainApp07_PantallaPrincipal extends AppCompatActivity {

    private ActivityMainApp07PantallaPrincipalBinding binding = null;
    private static final String KEY_RESULTADO = "Esperando resultado";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main_app07_pantalla_principal);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        binding = ActivityMainApp07PantallaPrincipalBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        if(savedInstanceState != null){
            binding.textView.setText(savedInstanceState.getString(KEY_RESULTADO,""));
        }

        binding.button.setOnClickListener(v -> {
            float cambio = Float.parseFloat((binding.editTextText.getText().toString()));
            int opcion = binding.radioGroup.getCheckedRadioButtonId();

            if(opcion == binding.radioButton1.getId()) {
                float resultado = (cambio * ((float) 9 / 5)) + 32;
                binding.textView.setText("Celsius a Fahrenheit = " + resultado);
            } else if (opcion == binding.radioButton2.getId()) {
                float resultado = (cambio / (float)20.49);
                binding.textView.setText("Pesos a Dolar = " + resultado);
            }else{
                Toast.makeText(this, "Selecciona una opción ", Toast.LENGTH_SHORT).show();
            }

        });

        Button btnRegresar = findViewById(R.id.btnRegresar);

        btnRegresar.setOnClickListener(v -> finish());

    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putString(KEY_RESULTADO,binding.textView.getText().toString());
    }
}