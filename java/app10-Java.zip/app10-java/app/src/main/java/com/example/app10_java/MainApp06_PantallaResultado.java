package com.example.app10_java;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class MainApp06_PantallaResultado extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main_app06_pantalla_resultado);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ArrayList<String> seleccionado = getIntent().getStringArrayListExtra("seleccionados");
        ImageView imageView = findViewById(R.id.imgPaketaxo);

        if (seleccionado != null) {
            Set<String> setSeleccionado = new HashSet<>(seleccionado);

            Set<String> paketaxoMezcladito = new HashSet<>(Arrays.asList("chetoBolita", "frito", "rancherito", "sabritone"));
            Set<String> paketaxoBotanero = new HashSet<>(Arrays.asList("crujitoFlamin", "churrumais", "sabritoneRodaca", "chetoPoff"));
            Set<String> paketaxoQuexo = new HashSet<>(Arrays.asList("chetoPoff", "dorito3d", "crujito", "chetoPalomita"));
            Set<String> paketaxoFlamin = new HashSet<>(Arrays.asList("chetoFlamin", "doritoFlamin", "sabritoneRodacaFlamin", "tostitoFlamin"));


            if (setSeleccionado.equals(paketaxoMezcladito)) {
                imageView.setImageResource(R.drawable.paketaxo_mezcladito);
            } else if (setSeleccionado.equals(paketaxoBotanero)) {
                imageView.setImageResource(R.drawable.paketaxo_botanero);
            } else if (setSeleccionado.equals(paketaxoQuexo)) {
                imageView.setImageResource(R.drawable.paketaxo_quexo);
            } else if (setSeleccionado.equals(paketaxoFlamin)) {
                imageView.setImageResource(R.drawable.paketaxo_flamin);
            } else {
                imageView.setImageResource(R.drawable.nohay_paketaxos);
            }
        }

        Button btnRegresar = findViewById(R.id.btnRegresar);

        btnRegresar.setOnClickListener(v ->{
            finish();
        });
    }
}