package com.example.app10_java;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainApp02 extends AppCompatActivity {

    private TextView objTxtViewResultado;
    private EditText objEditText;
    private static final String KEY_RESULTADO ="Esperando texto.....";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main_app02);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        objEditText = findViewById(R.id.editTextoIngresar);
        objTxtViewResultado = findViewById(R.id.textResultado);

        Button objBtnActualizar = findViewById(R.id.buttonActualizar);

        if(savedInstanceState != null){
            objTxtViewResultado.setText(savedInstanceState.getString(KEY_RESULTADO,""));
        }

        objBtnActualizar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String txtResultado = objEditText.getText().toString();
                objTxtViewResultado.setText(txtResultado);
            }
        });

        Button btnRegresar = findViewById(R.id.btnRegresar);

        btnRegresar.setOnClickListener(v -> finish());
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putString(KEY_RESULTADO, objTxtViewResultado.getText().toString());
    }
}