package com.example.app09_java_intent_implicitos;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private EditText nombre;
    private EditText carrera;
    private EditText grupo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button btnEnviar = findViewById(R.id.btnEnviar);

        btnEnviar.setOnClickListener( v -> {
            nombre = findViewById(R.id.txtEditNombre);
            carrera = findViewById(R.id.txtEditCarrera);
            grupo = findViewById(R.id.txtEditGrupo);

            String txtNombre = nombre.getText().toString();
            String txtCarrera = carrera.getText().toString();
            String txtGrupo = grupo.getText().toString();

            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("message/actividad09");
            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"m62346720@gmail.com"});
            intent.putExtra(Intent.EXTRA_SUBJECT,"Actividad 09");
            intent.putExtra(Intent.EXTRA_TEXT,"Nombre : " + txtNombre + "\n\r Carrera : " + txtCarrera + "\n\r Grupo : " + txtGrupo );

            try {
                startActivity(Intent.createChooser(intent,"Enviar correo... "));
            }catch (android.content.ActivityNotFoundException ex){
                Toast.makeText(this, "No hay aplicaciones de correo instaladas.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}