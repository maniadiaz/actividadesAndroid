package com.example.app09_java_intent_implicitos;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button btnEnviar = findViewById(R.id.button);
        Spinner comboBox = findViewById(R.id.comboBox);
        TextView txtFaseAlumno = findViewById(R.id.txtFaseAlumno);

        String[] lista = {"Selecciona un Alumno","Miguel Alexis Diaz Diaz","Katherine Galilea Guardado Garza", "Angel Adrian Ruiz Páez"};
        ArrayAdapter<String> list1 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,lista);
        list1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        comboBox.setAdapter(list1);

        comboBox.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String nombre = parent.getItemAtPosition(position).toString();

                if (nombre.equals("Miguel Alexis Diaz Diaz") || nombre.equals("Katherine Galilea Guardado Garza") || nombre.equals("Angel Adrian Ruiz Páez")) {
                    txtFaseAlumno.setText("Programación");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // No hacer nada
            }
        });


        btnEnviar.setOnClickListener( v -> {

            String nombre = comboBox.getSelectedItem().toString();

            if (nombre.equals("Miguel Alexis Diaz Diaz") || nombre.equals("Katherine Galilea Guardado Garza") || nombre.equals("Angel Adrian Ruiz Páez")) {
                String[][] horario = {
                        {"Hora", "Materia", "Profesor"},
                        {"08:00 - 08:50 AM", "Derecho Informático", "Mtra. Delma Mendoza Tirado"},
                        {"08:50 - 09:40 AM", "Sistemas de Información Geográfica", "Prof. Erik Iván Sánchez Valdez"},
                        {"09:40 - 10:30 AM", "Desarrollo de Aplicaciones Móviles", "Prof. Juan Jose Rodriguez Malpica G"},
                        {"10:30 - 11:20 AM", "Programación de Videojuegos", "Prof. Ulises Zaldívar Colado"},
                        {"11:20 - 12:10 PM", "Administración de Páginas Web", "Prof. Juan Francisco Peraza Garzón"},
                        {"12:10 - 1:00 PM", "Interacción Hombre-Máquina", "Prof. Esteban Bernal Malagon"}
                };

                int[] columnWidths = {20, 35, 35};
                StringBuilder tablaTexto = new StringBuilder();

                String separador = "-".repeat(columnWidths[0] + columnWidths[1] + columnWidths[2]);
                tablaTexto.append("HORARIO DE CLASES\n");
                tablaTexto.append(separador + "\n");

                for (String[] fila : horario) {
                    for (int j = 0; j < fila.length; j++) {
                        tablaTexto.append(String.format("%-" + columnWidths[j] + "s", fila[j]));
                    }
                    tablaTexto.append("\n");
                }

                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("message/rfc822");
                intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"m62346720@gmail.com"});
                intent.putExtra(Intent.EXTRA_SUBJECT, "Actividad 09 " + nombre);
                intent.putExtra(Intent.EXTRA_TEXT, nombre + "\n\n" + tablaTexto.toString());

                try {
                    startActivity(Intent.createChooser(intent, "Enviar correo... "));
                } catch (android.content.ActivityNotFoundException ex) {
                    Toast.makeText(this, "No hay aplicaciones de correo instaladas.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(MainActivity.this, "Por favor, selecciona un integrante.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}