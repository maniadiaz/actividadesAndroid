package com.example.app_cambios;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.example.app_cambios.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding = null;
    private static final String KEY_RESULTADO = "Esperando resultado";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        if(savedInstanceState != null){
            binding.textView.setText(savedInstanceState.getString(KEY_RESULTADO,""));
        }

        binding.button.setOnClickListener(v -> {
            float cambio = Float.parseFloat((binding.editTextText.getText().toString()));
            int opcion = binding.radioGroup.getCheckedRadioButtonId();

            if(opcion == binding.radioButton1.getId()) {
                float resultado = (cambio * ((float) 9 / 5)) + 32;
                binding.textView.setText("Celsius a Fahrenheit = " + resultado);
            } else if (opcion == binding.radioButton2.getId()) {
                float resultado = (cambio * (float)20.49);
                binding.textView.setText("Pesos a Dolar = " + resultado);
            }else{
                Toast.makeText(MainActivity.this, "Selecciona una opción ", Toast.LENGTH_SHORT).show();
            }

        });
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putString(KEY_RESULTADO,binding.textView.getText().toString());
    }
}