package com.example.actividad10_kotlin

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainApp03 : AppCompatActivity() {

    private var txtOncreate : TextView? = null
    private var txtOnStart : TextView? = null
    private var txtOnStop : TextView? = null
    private var txtOnPause : TextView? = null
    private var txtOnResume : TextView? = null
    private var txtOnDestroy : TextView? = null
    private var txtOnRestart : TextView? = null
    private var txtOnClick : TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main_app03)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        txtOncreate = findViewById(R.id.txtOnCreate);
        txtOnStart = findViewById(R.id.txtOnStart);
        txtOnStop = findViewById(R.id.txtOnStop);
        txtOnPause = findViewById(R.id.txtOnPause);
        txtOnResume = findViewById(R.id.txtOnResume);
        txtOnDestroy = findViewById(R.id.txtOnDestroy);
        txtOnRestart = findViewById(R.id.txtOnRestart);
        txtOnClick = findViewById(R.id.txtOnClick);

        Log.d("onCreate","Metodo onCreate Ejecutado")
        txtOncreate?.text = "Metodo Oncreate"

        val btnMostrar : Button = findViewById(R.id.button)
        btnMostrar.setOnClickListener(View.OnClickListener {
            Log.d("BtnClcik","Boton Presionado")
            txtOnClick?.text = "Boton presionado"
        })

        val btnRegresar = findViewById<Button>(R.id.btnRegresar)
        btnRegresar.setOnClickListener { v: View? ->
            finish()
        }
    }

    override fun onStart() {
        super.onStart()
        Log.d("onStart", "Método onStart ejecutado");
        txtOnStart?.text = "Metodo onStart"
    }

    override fun onResume() {
        super.onResume()
        Log.d("onResume", "Método onResume ejecutado")
        txtOnResume?.text = "Método onResume"
    }

    override fun onPause() {
        super.onPause()
        Log.d("onPause", "Método onPause ejecutado")
        txtOnPause?.text = "Método onPause"
    }

    override fun onStop() {
        super.onStop()
        Log.d("onStop", "Método onStop ejecutado")
        txtOnStop?.text = "Método onStop"
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("onDestroy", "Método onDestroy ejecutado")
        txtOnDestroy?.text = "Método onDestroy"
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("onRestart", "Método onRestart ejecutado")
        txtOnRestart?.text = "Método onRestart"
    }
}