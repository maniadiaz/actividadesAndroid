package com.example.actividad10_kotlin

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainApp06_PantallaResultado : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main_app06_pantalla_resultado)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val seleccionado = intent.getStringArrayListExtra("seleccionados")
        val imageView = findViewById<ImageView>(R.id.imgPaketaxo)

        if (seleccionado != null) {
            val setSeleccionado = seleccionado.toSet()

            val paketaxoMezcladito = setOf("chetoBolita", "frito", "rancherito", "sabritone")
            val paketaxoBotanero = setOf("crujitoFlamin", "churrumais", "sabritoneRodaca", "chetoPoff")
            val paketaxoQuexo = setOf("chetoPoff", "dorito3d", "crujito", "chetoPalomita")
            val paketaxoFlamin = setOf("chetoFlamin", "doritoFlamin", "sabritoneRodacaFlamin", "tostitoFlamin")

            imageView.setImageResource(
                when (setSeleccionado) {
                    paketaxoMezcladito -> R.drawable.paketaxo_mezcladito
                    paketaxoBotanero -> R.drawable.paketaxo_botanero
                    paketaxoQuexo -> R.drawable.paketaxo_quexo
                    paketaxoFlamin -> R.drawable.paketaxo_flamin
                    else -> R.drawable.nohay_paketaxos
                }
            )
        }

        val btnRegresar = findViewById<Button>(R.id.btnRegresar)
        btnRegresar.setOnClickListener {
            finish()
        }
    }
}