package com.example.actividad10_kotlin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainApp05_PantallaResultado : AppCompatActivity() {

    private var txtResultado: TextView? = null
    private var btnRegresar: Button? = null
    private var intent: Intent? = null
    private var ingrediente1: String? = null
    private var ingrediente2: String? = null
    private var ingrediente3: String? = null
    private var ingrediente4: String? = null
    private var resultado: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main_app05_pantalla_resultado)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        txtResultado = findViewById(R.id.txtResultado)
        btnRegresar = findViewById(R.id.btnRegresar)
        intent = getIntent()

        ingrediente1 = intent?.getStringExtra("ingrediente1")
        ingrediente2 = intent?.getStringExtra("ingrediente2")
        ingrediente3 = intent?.getStringExtra("ingrediente3")
        ingrediente4 = intent?.getStringExtra("ingrediente4")


        resultado = if (ingrediente1 == "Cafe" && ingrediente2 == "Nada" && ingrediente3 == "Nada" && ingrediente4 == "Nada") {
            "Expresso"
        } else if (ingrediente1 == "Cafe" && ingrediente2 == "Agua caliente" && ingrediente3 == "Nada" && ingrediente4 == "Nada") {
            "Americano"
        } else if (ingrediente1 == "Cafe" && ingrediente2 == "Leche evaporada" && ingrediente3 == "Vainilla" && ingrediente4 == "Espuma de leche") {
            "Cappuccino"
        } else if (ingrediente1 == "Cafe" && ingrediente2 == "Leche evaporada" && ingrediente3 == "Espuma de leche" && ingrediente4 == "Nada") {
            "Latte"
        } else if (ingrediente1 == "Cafe" && ingrediente2 == "Leche evaporada" && ingrediente3 == "Nada" && ingrediente4 == "Nada") {
            "Macchiato"
        } else if (ingrediente1 == "Chocolate" && ingrediente2 == "Cafe" && ingrediente3 == "Leche evaporada" && ingrediente4 == "Espuma de leche") {
            "Mocca"
        } else if (ingrediente1 == "Cafe" && ingrediente2 == "Orijo/Brandy" && ingrediente3 == "Nada" && ingrediente4 == "Nada") {
            "Carajillo"
        } else if (ingrediente1 == "Cafe" && ingrediente2 == "Whiskey" && ingrediente3 == "Espuma de leche" && ingrediente4 == "Nada") {
            "Irish Coffee"
        } else {
            "No se encontró una coincidencia para este café."
        }

        txtResultado?.text = "Café " + resultado

        btnRegresar?.setOnClickListener{
            finish()
        }
    }
}