package com.example.actividad10_kotlin

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        // instanciar de botones
        val btnApp01 = findViewById<Button>(R.id.btnApp01)
        val btnApp02 = findViewById<Button>(R.id.btnApp02)
        val btnApp03 = findViewById<Button>(R.id.btnApp03)
        val btnApp04 = findViewById<Button>(R.id.btnApp04)
        val btnApp05 = findViewById<Button>(R.id.btnApp05)
        val btnApp06 = findViewById<Button>(R.id.btnApp06)
        val btnApp07 = findViewById<Button>(R.id.btnApp07)
        val btnApp08 = findViewById<Button>(R.id.btnApp08)
        val btnApp09 = findViewById<Button>(R.id.btnApp09)


        // instanciar los intent
        val intent01 = Intent(this, MainApp01::class.java)
        val intent02 = Intent(this, MainApp02::class.java)
        val intent03 = Intent(this, MainApp03::class.java)
        val intent04 = Intent(this, MainApp04_PantallaPrincipal::class.java)
        val intent05 = Intent(this, MainApp05_PantallaPrincipal::class.java)
        val intent06 = Intent(this, MainApp06_PantallaPrincipal::class.java)
        val intent07 = Intent(this, MainApp07_PantallaPrincipal::class.java)
        val intent08 = Intent(this, MainApp08_PantallaPrincipal::class.java)
        val intent09 = Intent(this, MainApp09_PantallaPrincipal::class.java)


        // App 01
        btnApp01.setOnClickListener { v: View? ->
            startActivity(intent01)
        }


        // App 02
        btnApp02.setOnClickListener { v: View? ->
            startActivity(intent02)
        }


        // App 03
        btnApp03.setOnClickListener { v: View? ->
            startActivity(intent03)
        }


        // App 04
        btnApp04.setOnClickListener { v: View? ->
            startActivity(intent04)
        }


        // App 05
        btnApp05.setOnClickListener { v: View? ->
            startActivity(intent05)
        }


        // App 06
        btnApp06.setOnClickListener { v: View? ->
            startActivity(intent06)
        }


        // App 07
        btnApp07.setOnClickListener { v: View? ->
            startActivity(intent07)
        }


        // App 08
        btnApp08.setOnClickListener { v: View? ->
            startActivity(intent08)
        }


        // App 09
        btnApp09.setOnClickListener { v: View? ->
            startActivity(intent09)
        }
    }
}