package com.example.actividad10_kotlin

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainApp02 : AppCompatActivity() {

    private var objTxtViewResultado : TextView? = null
    private var objEditText : EditText? = null
    private var KEY_RESULTADO : String? = "Esperando texto....."

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main_app02)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        objEditText = findViewById(R.id.editTextoIngresar)
        objTxtViewResultado = findViewById(R.id.textResultado);
        var objBtnActualizar : Button = findViewById(R.id.buttonActualizar)

        savedInstanceState?.let{
            objTxtViewResultado?.text = it.getString(KEY_RESULTADO,"")
        }

        objBtnActualizar.setOnClickListener{
            val txtResultado = objEditText?.text.toString()
            objTxtViewResultado?.text = txtResultado

        }

        val btnRegresar = findViewById<Button>(R.id.btnRegresar)
        btnRegresar.setOnClickListener { v: View? ->
            finish()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(KEY_RESULTADO, objTxtViewResultado?.text.toString())
    }
}