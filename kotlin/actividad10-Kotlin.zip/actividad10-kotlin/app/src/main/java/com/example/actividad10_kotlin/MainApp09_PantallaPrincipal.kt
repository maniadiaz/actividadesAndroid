package com.example.actividad10_kotlin

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainApp09_PantallaPrincipal : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main_app09_pantalla_principal)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btnEnviar = findViewById<Button>(R.id.button)
        val comboBox = findViewById<Spinner>(R.id.comboBox)
        val txtFaseAlumno = findViewById<TextView>(R.id.txtFaseAlumno)

        val lista = arrayOf("Selecciona un Alumno", "Miguel Alexis Diaz Diaz", "Katherine Galilea Guardado Garza", "Angel Adrian Ruiz Páez")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, lista)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        comboBox.adapter = adapter

        comboBox.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                val nombre = parent.getItemAtPosition(position).toString()
                if (nombre in listOf("Miguel Alexis Diaz Diaz", "Katherine Galilea Guardado Garza", "Angel Adrian Ruiz Páez")) {
                    txtFaseAlumno.text = "Programación"
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // No hacer nada
            }
        }

        btnEnviar.setOnClickListener {
            val nombre = comboBox.selectedItem.toString()

            if (nombre in listOf("Miguel Alexis Diaz Diaz", "Katherine Galilea Guardado Garza", "Angel Adrian Ruiz Páez")) {
                val horario = arrayOf(
                    arrayOf("Hora", "Materia", "Profesor"),
                    arrayOf("08:00 - 08:50 AM", "Derecho Informático", "Mtra. Delma Mendoza Tirado"),
                    arrayOf("08:50 - 09:40 AM", "Sistemas de Información Geográfica", "Prof. Erik Iván Sánchez Valdez"),
                    arrayOf("09:40 - 10:30 AM", "Desarrollo de Aplicaciones Móviles", "Prof. Juan Jose Rodriguez Malpica G"),
                    arrayOf("10:30 - 11:20 AM", "Programación de Videojuegos", "Prof. Ulises Zaldívar Colado"),
                    arrayOf("11:20 - 12:10 PM", "Administración de Páginas Web", "Prof. Juan Francisco Peraza Garzón"),
                    arrayOf("12:10 - 1:00 PM", "Interacción Hombre-Máquina", "Prof. Esteban Bernal Malagon")
                )

                val columnWidths = intArrayOf(20, 35, 35)
                val tablaTexto = StringBuilder()

                val separador = "-".repeat(columnWidths.sum())
                tablaTexto.append("HORARIO DE CLASES\n")
                tablaTexto.append(separador).append("\n")

                for (fila in horario) {
                    for ((index, item) in fila.withIndex()) {
                        tablaTexto.append(String.format("%-${columnWidths[index]}s", item))
                    }
                    tablaTexto.append("\n")
                }

                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "message/rfc822"
                    putExtra(Intent.EXTRA_EMAIL, arrayOf("m62346720@gmail.com"))
                    putExtra(Intent.EXTRA_SUBJECT, "Actividad 09 $nombre Kotlin")
                    putExtra(Intent.EXTRA_TEXT, "$nombre Kotlin \n\n${tablaTexto.toString()}")
                }

                try {
                    startActivity(Intent.createChooser(intent, "Enviar correo... "))
                } catch (ex: android.content.ActivityNotFoundException) {
                    Toast.makeText(this@MainApp09_PantallaPrincipal, "No hay aplicaciones de correo instaladas.", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this@MainApp09_PantallaPrincipal, "Por favor, selecciona un integrante.", Toast.LENGTH_SHORT).show()
            }
        }

        val btnRegresar = findViewById<Button>(R.id.btnRegresar)
        btnRegresar.setOnClickListener { v: View? ->
            finish()
        }
    }
}