package com.example.actividad10_kotlin

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainApp05_PantallaPrincipal : AppCompatActivity() {

    private var spinnerIngrediente1 : Spinner? = null
    private var spinnerIngrediente2 : Spinner? = null
    private var spinnerIngrediente3 : Spinner? = null
    private var spinnerIngrediente4 : Spinner? = null
    private var intent : Intent? = null
    private var btnEnviar : Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main_app05_pantalla_principal)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        spinnerIngrediente1 = findViewById(R.id.spinner1)
        spinnerIngrediente2 = findViewById(R.id.spinner2)
        spinnerIngrediente3 = findViewById(R.id.spinner3)
        spinnerIngrediente4 = findViewById(R.id.spinner4)
        btnEnviar = findViewById(R.id.btnGenerar)

        val ingrediente1 = arrayOf("Selecciona un ingrediente", "Cafe", "Chocolate")
        val ingrediente2 = arrayOf("Selecciona un ingrediente", "Nada", "Agua caliente", "Leche evaporada", "Cafe", "Orijo/Brandy", "Whiskey")
        val ingrediente3 = arrayOf("Selecciona un ingrediente", "Nada", "Vainilla", "Espuma de leche", "Leche evaporada")
        val ingrediente4 = arrayOf("Selecciona un ingrediente", "Nada", "Espuma de leche")

        val adapter1 = ArrayAdapter(this, android.R.layout.simple_spinner_item, ingrediente1)
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerIngrediente1?.adapter = adapter1

        val adapter2 = ArrayAdapter(this, android.R.layout.simple_spinner_item, ingrediente2)
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerIngrediente2?.adapter = adapter2

        val adapter3 = ArrayAdapter(this, android.R.layout.simple_spinner_item, ingrediente3)
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerIngrediente3?.adapter = adapter3

        val adapter4 = ArrayAdapter(this, android.R.layout.simple_spinner_item, ingrediente4)
        adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerIngrediente4?.adapter = adapter4


        btnEnviar?.setOnClickListener{
            var ingre1 = spinnerIngrediente1?.getSelectedItem().toString()
            val ingre2 = spinnerIngrediente2?.getSelectedItem().toString()
            val ingre3 = spinnerIngrediente3?.getSelectedItem().toString()
            val ingre4 = spinnerIngrediente4?.getSelectedItem().toString()

            if (ingre1 == "Selecciona un ingrediente" || ingre2 == "Selecciona un ingrediente" || ingre3 == "Selecciona un ingrediente" || ingre4 == "Selecciona un ingrediente") {
                Toast.makeText(
                    this,
                    "Por favor, selecciona todo los ingrediente",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                intent = Intent(this, MainApp05_PantallaResultado::class.java)
                intent!!.putExtra("ingrediente1", ingre1)
                intent!!.putExtra("ingrediente2", ingre2)
                intent!!.putExtra("ingrediente3", ingre3)
                intent!!.putExtra("ingrediente4", ingre4)

                startActivity(intent)
            }
        }

        val btnRegresar = findViewById<Button>(R.id.btnRegresar)
        btnRegresar.setOnClickListener { v: View? ->
            finish()
        }
    }
}