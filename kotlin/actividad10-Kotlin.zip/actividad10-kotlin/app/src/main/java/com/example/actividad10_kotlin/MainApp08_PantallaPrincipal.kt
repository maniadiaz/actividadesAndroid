package com.example.actividad10_kotlin

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainApp08_PantallaPrincipal : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main_app08_pantalla_principal)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val txtFaseAlumno : TextView = findViewById(R.id.txtFaseAlumno)

        val lista = arrayOf("Selecciona un Alumno","Miguel Alexis Diaz Diaz","Katherine Galilea Guardado Garza", "Angel Adrian Ruiz Páez")
        val list1 = ArrayAdapter(this, android.R.layout.simple_spinner_item, lista)
        list1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        val comboBox : Spinner = findViewById(R.id.comboBox)
        comboBox.adapter = list1

        comboBox.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val nombre = parent?.getItemAtPosition(position).toString()

                if (nombre in listOf("Miguel Alexis Diaz Diaz", "Katherine Galilea Guardado Garza", "Angel Adrian Ruiz Páez"
                    )
                ) {
                    txtFaseAlumno.text = "Programación Kotlin"
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // No hacer nada
            }
        }

        val btnEnviar = findViewById<Button>(R.id.button)

        btnEnviar.setOnClickListener(View.OnClickListener {
            val nombre = comboBox.selectedItem.toString()
            if (nombre == "Miguel Alexis Diaz Diaz" || nombre == "Katherine Galilea Guardado Garza" || nombre == "Angel Adrian Ruiz Páez") {
                val intent = Intent(this, MainApp08_PantallaResultado::class.java)
                intent.putExtra("Alumno", nombre)
                intent.putExtra("Fase", "Programación")
                startActivity(intent)
            } else {
                Toast.makeText(this, "Por Favor de Seleccionar un Integrante", Toast.LENGTH_SHORT).show()
            }
        })

        val btnRegresar = findViewById<Button>(R.id.btnRegresar)
        btnRegresar.setOnClickListener { v: View? ->
            finish()
        }
    }
}