package com.example.actividad06_kotlin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btnEnviar = findViewById<Button>(R.id.btnEnviar)

        val chetoBolita = findViewById<CheckBox>(R.id.chetoBolita)
        val frito = findViewById<CheckBox>(R.id.frito)
        val crujitoFlamin = findViewById<CheckBox>(R.id.crujitoFlamin)
        val churrumais = findViewById<CheckBox>(R.id.churrumais)
        val dorito3d = findViewById<CheckBox>(R.id.dorito3d)
        val crujito = findViewById<CheckBox>(R.id.crujito)
        val doritoFlamin = findViewById<CheckBox>(R.id.doritoFlamin)
        val sabritoneRodacaFlamin = findViewById<CheckBox>(R.id.sabritoneRodacaFlamin)
        val sabritone = findViewById<CheckBox>(R.id.sabritones)
        val chetoPoff = findViewById<CheckBox>(R.id.chetoPoff)
        val chetoFlamin = findViewById<CheckBox>(R.id.chetoFlamin)
        val rancherito = findViewById<CheckBox>(R.id.rancherito)
        val sabritoneRodaca = findViewById<CheckBox>(R.id.sabritoneRodaca)
        val chetoPalomita = findViewById<CheckBox>(R.id.chetoPalomita)
        val tostitoFlamin = findViewById<CheckBox>(R.id.tostitoFlamin)

        btnEnviar.setOnClickListener {
            val intent = Intent(this, MainActivity2::class.java)
            val seleccionados = arrayListOf<String>()

            val checkboxes = listOf(
                chetoBolita to "chetoBolita",
                frito to "frito",
                crujitoFlamin to "crujitoFlamin",
                churrumais to "churrumais",
                dorito3d to "dorito3d",
                crujito to "crujito",
                doritoFlamin to "doritoFlamin",
                sabritoneRodacaFlamin to "sabritoneRodacaFlamin",
                sabritone to "sabritone",
                chetoPoff to "chetoPoff",
                chetoFlamin to "chetoFlamin",
                rancherito to "rancherito",
                sabritoneRodaca to "sabritoneRodaca",
                chetoPalomita to "chetoPalomita",
                tostitoFlamin to "tostitoFlamin"
            )

            checkboxes.forEach { (checkbox, name) ->
                if (checkbox.isChecked) seleccionados.add(name)
            }

            intent.putStringArrayListExtra("seleccionados", seleccionados)
            startActivity(intent)
        }


    }
}