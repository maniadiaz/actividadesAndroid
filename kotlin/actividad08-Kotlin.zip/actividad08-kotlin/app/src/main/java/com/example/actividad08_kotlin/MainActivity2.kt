package com.example.actividad08_kotlin

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.TableRow
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.actividad08_kotlin.databinding.ActivityMain2Binding

class MainActivity2 : AppCompatActivity() {

    private var intentData: Intent? = null
    private lateinit var binding: ActivityMain2Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        binding = ActivityMain2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        val encabezadoRow = TableRow(this)

        val horarioEncabezado = crearTextView("Horario")
        val materiaEncabezado = crearTextView("Materia")
        val docenteEncabezado = crearTextView("Docente")

        encabezadoRow.apply {
            addView(horarioEncabezado)
            addView(materiaEncabezado)
            addView(docenteEncabezado)
        }

        binding.tableLayout.addView(encabezadoRow)

        intentData = intent

        val nombreAlumno = intentData?.getStringExtra("Alumno")
        val fase = intentData?.getStringExtra("Fase")

        binding.txtNombre.text = "Enviado Kotlin \n \r Alumno: $nombreAlumno"

        if (fase == "Programación") {
            val horario = arrayOf(
                arrayOf("08:00 - 08:50 AM", "Derecho Informático", "Mtra. Delma Mendoza Tirado"),
                arrayOf("08:50 - 09:40 AM", "Sistemas de información geográfica", "Prof. Erik Iván Sánchez Valdez"),
                arrayOf("09:40 - 10:30 AM", "Desarrollo de aplicaciones móviles", "Prof. Juan Jose Rodriguez Malpica G"),
                arrayOf("10:30 - 11:20 AM", "Programación de videojuegos", "Prof. Ulises Zaldívar Colado"),
                arrayOf("11:20 - 12:10 PM", "Administración de páginas web", "Prof. Juan Francisco Peraza Garzón"),
                arrayOf("12:10 - 1:00 PM", "Interacción Hombre-Máquina", "Prof. Esteban Bernal Malagon")
            )

            for (row in horario) {
                val tablaRow = TableRow(this)

                val horarioText = crearTextView(row[0])
                val materiaText = crearTextView(row[1])
                val docenteText = crearTextView(row[2])

                tablaRow.apply {
                    addView(horarioText)
                    addView(materiaText)
                    addView(docenteText)
                }

                binding.tableLayout.addView(tablaRow)
            }
        }

        binding.button2.setOnClickListener {
            finish()
        }

    }


    private fun crearTextView(texto: String): TextView {
        return TextView(this).apply {
            text = texto
            textSize = 14f
            setPadding(90, 16, 16, 16)
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#336699"))
        }
    }
}