package com.example.actividad05_kotlin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity2 : AppCompatActivity() {

    private var txtResultado: TextView? = null
    private var btnRegresar: Button? = null
    private var intent: Intent? = null
    private var ingrediente1: String? = null
    private var ingrediente2: String? = null
    private var ingrediente3: String? = null
    private var ingrediente4: String? = null
    private var resultado: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        txtResultado = findViewById(R.id.txtResultado)
        btnRegresar = findViewById(R.id.btnRegresar)
        intent = getIntent()

        ingrediente1 = intent?.getStringExtra("ingrediente1")
        ingrediente2 = intent?.getStringExtra("ingrediente2")
        ingrediente3 = intent?.getStringExtra("ingrediente3")
        ingrediente4 = intent?.getStringExtra("ingrediente4")


        /*
            Expresso :
            1.- cafe
        */
        resultado = if (ingrediente1 == "Cafe" && ingrediente2 == "Nada" && ingrediente3 == "Nada" && ingrediente4 == "Nada") {
            "Expresso"
        } else
        /*
            Americano :
            1.- Cafe
            2.- Agua
        */
        if (ingrediente1 == "Cafe" && ingrediente2 == "Agua caliente" && ingrediente3 == "Nada" && ingrediente4 == "Nada") {
            "Americano"
        } else
        /*
            Cappuccino :
            1.- cafe
            2.- Leche
            3.- Vainilla
            4.- Espuma de leche
         */
        if (ingrediente1 == "Cafe" && ingrediente2 == "Leche evaporada" && ingrediente3 == "Vainilla" && ingrediente4 == "Espuma de leche") {
            "Cappuccino"
        } else
        /*
            Latte :
            1.- Cafe
            2.- Leche
            3.- Espuma de leche
         */
        if (ingrediente1 == "Cafe" && ingrediente2 == "Leche evaporada" && ingrediente3 == "Espuma de leche" && ingrediente4 == "Nada") {
            "Latte"
        } else
        /*
            Machiatto :
            1.- Cafe
            2.- Leche
         */
        if (ingrediente1 == "Cafe" && ingrediente2 == "Leche evaporada" && ingrediente3 == "Nada" && ingrediente4 == "Nada") {
            "Macchiato"
        } else
        /*
            Mocca :
            1.- Chocolate
            2.- Cafe
            3.- leche
            4.- Espuma de leche
         */
        if (ingrediente1 == "Chocolate" && ingrediente2 == "Cafe" && ingrediente3 == "Leche evaporada" && ingrediente4 == "Espuma de leche") {
            "Mocca"
        } else
        /*
            Carajillo :
            1.- Cafe
            2.- Orujo/Brandy
         */
        if (ingrediente1 == "Cafe" && ingrediente2 == "Orijo/Brandy" && ingrediente3 == "Nada" && ingrediente4 == "Nada") {
            "Carajillo"
        } else
        /*
            Irish :
            1.- Cafe
            2.- Whiskey
            3.- Espuma de leche
         */
        if (ingrediente1 == "Cafe" && ingrediente2 == "Whiskey" && ingrediente3 == "Espuma de leche" && ingrediente4 == "Nada") {
            "Irish Coffee"
        } else {
            "No se encontró una coincidencia para este café."
        }

        txtResultado?.text = "Café " + resultado

        btnRegresar?.setOnClickListener{
            finish()
        }
    }
}