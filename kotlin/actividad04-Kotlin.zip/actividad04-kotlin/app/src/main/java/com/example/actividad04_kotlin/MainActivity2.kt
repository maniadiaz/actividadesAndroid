package com.example.actividad04_kotlin

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity2 : AppCompatActivity() {

    private var txtNombre : TextView? = null
    private var txtCarrera : TextView? = null
    private var txtGrupo : TextView? = null
    private var btnRegresar : Button? = null
    private var nombre : String? = null
    private var carrera : String? = null
    private var grupo : String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        var intent : Intent? = null;

        intent = getIntent()

        nombre = intent.getStringExtra("nombre")
        carrera = intent.getStringExtra("carrera")
        grupo = intent.getStringExtra("grupo")

        txtNombre = findViewById(R.id.act2TxtNombre)
        txtCarrera = findViewById(R.id.act2TxtCarrera)
        txtGrupo = findViewById(R.id.act2TxtGrupo)
        btnRegresar = findViewById(R.id.act2BtnRegresar)

        txtNombre?.text = nombre
        txtCarrera?.text = carrera
        txtGrupo?.text = grupo

        btnRegresar?.setOnClickListener{
            finish()
        }
    }


}