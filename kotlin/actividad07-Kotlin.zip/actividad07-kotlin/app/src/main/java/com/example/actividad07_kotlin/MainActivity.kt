package com.example.actividad07_kotlin

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.actividad07_kotlin.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    val KEY_RESULTADO : String = "Esperando resultado kotlin"
    var binding : ActivityMainBinding? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding?.root)

        savedInstanceState?.let {
            binding?.textView?.text= savedInstanceState.getString(KEY_RESULTADO,"")
        }

        binding?.button?.setOnClickListener(View.OnClickListener {
            val cambio = (binding?.editTextText?.text.toString()).toFloat()
            val opcion = binding?.radioGroup?.checkedRadioButtonId
            if (opcion == binding?.radioButton1?.id) {
                val resultado = (cambio * (9f / 5)) + 32
                binding?.textView?.text = "Kotlin -> Celsius a Fahrenheit = $resultado"
            } else if (opcion == binding?.radioButton2?.id) {
                val resultado = (cambio / 20.49.toFloat())
                binding?.textView?.text = "Kotlin -> Pesos a Dolar = $resultado"
            } else {
                Toast.makeText(this@MainActivity, "Selecciona una opción ", Toast.LENGTH_SHORT).show()
            }
        })
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(KEY_RESULTADO,binding?.textView?.text.toString())
    }
}